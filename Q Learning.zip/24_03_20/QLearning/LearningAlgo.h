/*
 * LearningAlgo.h
 *
 *  Created on: Mar 4, 2020
 *      Author: master
 */


#ifndef LearningAlgo_HEADER
#define LearningAlgo_HEADER


#include <omnetpp.h>
#include <iostream>
#include <string>
#include <string.h>
#include <time.h>
#include "stack/phy/layer/LtePhyUe.h"

class LtePhyUe;

#define ALPHA 0.8
#define GAMMA 0.9
#define EPILSONE 0.2
#define ACTION_NUM 4
#define STATE_NUM 4
#define MAX_EP 200



class LearningAlgo{

    private:
        double** Q;
        int* action_list_;
        int* state_list_;
        int* list_rssi;
        int action_;
        int state_;
        int next_state_;
        double reward_;
        bool done_;
        int max_action_;
        double maxQ_;
        double oldQ_value_;
        double newQ_value_;
        int trained_action_;
        int init_state_;

    public:
        void actionDo(int state);

        void actionGet();

        void getActionMax();

        void setMaxQ();

        bool getDone(){
            return done_;
        }
        void initiliaze_action_state_list();

        double FloatRandom(double a , double b);

        void set_init_state(int init_state){
            init_state_ = init_state;
        }

        void initializeRssiList();

        int getListRssi(int index){
            return list_rssi[index];
        }

        void setListRssi(int index, int value){
            list_rssi[index] = value;
        }
        int get_init_state(){
            return init_state_;
        }

        void initialize_QTable();

        double** getQ_table(){
            return Q;
        }

        void setQ_table_value(int row, int column, double value){
            Q[row][column] = value;
        }

        double getQ_Table_Value(int row, int column){
            return Q[row][column];
        }

        void getTrainedAction(int state);
        int getTrainedAct(){
            return trained_action_;
        }
        bool observa(int state);

       // void initializeQ_table();
        void printQ_Table();

        double getReward(){
            return reward_;
        }

        int getAction(){
            return action_;
        }

        int getState(){
            return state_;
        }

        int getNextState(){
            return next_state_;
        }

        void setAction(int action){
            action_ = action;
        }

        void setState(int state){
            state_ = state;
        }

        void setNextState(int next_state){
            next_state_ = next_state;
        }

        void setReward(double reward){
            reward_ = reward;
        }
void getMaxAct(int position);
        int action_state_to_index(int a, int b[ACTION_NUM]);

        void setOldQ_value(double oldQ_value){
            oldQ_value_= oldQ_value;
        }

        void setNewQ_value(double newQ_value){
             newQ_value_= newQ_value;
        }

        double getOldQ_value(){
            return oldQ_value_;
        }

        double getNewQ_value(){
            return newQ_value_;
        }


        double getMaxQ(){
            return maxQ_;
        }

        int* getAction_list(){
            return action_list_;
        }

        int* getState_list(){
            return state_list_;
        }

        void print_State_Action(int* b);

        void setTrained_action(int trained_action){
            trained_action_= trained_action;
        }

        int getTrained_action(){
            return trained_action_;
        }

        double FloatRandom2(double a, double b);

        void deleteQ();
        bool qNull();
};

#endif

